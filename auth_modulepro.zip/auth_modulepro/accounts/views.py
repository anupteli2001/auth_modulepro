# accounts/views.py
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.conf import settings
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.contrib.sites.shortcuts import get_current_site
from .forms import SignUpForm, LoginForm
from .models import CustomUser
from .tokens import account_activation_token

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.email_verified = False
            user.save()
            send_verification_email(request, user)
            return redirect('login')
    else:
        form = SignUpForm()
    return render(request, 'accounts/signup.html', {'form': form})

def send_verification_email(request, user):
    current_site = get_current_site(request)
    subject = 'Verify Your Email'
    message = f"""
    Hi {user.first_name},
    Please click the link below to verify your email:
    http://{current_site.domain}/verify-email/{urlsafe_base64_encode(force_bytes(user.pk))}/{account_activation_token.make_token(user)}/
    """
    send_mail(subject, message, settings.EMAIL_HOST_USER, [user.email])

def verify_email(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = CustomUser.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, CustomUser.DoesNotExist):
        user = None

    if user is not None and account_activation_token.check_token(user, token):
        user.email_verified = True
        user.save()
        return redirect('login')
    else:
        return render(request, 'accounts/verification_failed.html')

def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            if user.email_verified:
                login(request, user)
                return redirect('about')
            else:
                return render(request, 'accounts/login.html', {'form': form, 'error': 'Email not verified'})
    else:
        form = LoginForm()
    return render(request, 'accounts/login.html', {'form': form})

@login_required
def about(request):
    return render(request, 'accounts/about.html')

def user_logout(request):
    logout(request)
    return redirect('login')